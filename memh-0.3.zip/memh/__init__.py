import os
from .ffi import ffi

_memh = ffi.dlopen(os.path.join(os.path.dirname(__file__), 'memh.so'))

# TODO: Find a normal way
for func in dir(_memh): 
    globals()[func] = getattr(_memh, func)

del os