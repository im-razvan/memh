from setuptools import setup

setup(
   name='memh',
   version='0.1',
   description='Small Python Library for Reading and Writing Memory',
   author='Razvan',
   packages=['memh'],
   include_package_data=True,
    install_requires=[
        'cffi==1.15.1',
    ],
)