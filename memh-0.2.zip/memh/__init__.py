__all__ = ["memh", "ffi"]

import os
from .ffi import ffi

memh = ffi.dlopen(os.path.join(os.path.dirname(__file__), 'memh.so'))
del os