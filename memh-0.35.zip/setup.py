from setuptools import setup

setup(
   name='memh',
   version='0.35',
   description='Small & Fast Python Library for Reading and Writing Memory.',
   author='Razvan',
   packages=['memh'],
   include_package_data=True,
   install_requires=[
       'cffi==1.16.0',
   ],
)